package com.test.deployApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestDeployAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
